
// AI機能は削除されました
export const getScheduleSummary = async () => {
  return "";
};
