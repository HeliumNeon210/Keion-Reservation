import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import fs from "fs";

const db = new Database("reservations.db");

// Initialize database
db.exec(`
  CREATE TABLE IF NOT EXISTS reservations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT NOT NULL,
    startTime TEXT NOT NULL,
    bandName TEXT NOT NULL,
    memberCount INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS available_slots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    dayOfWeek INTEGER NOT NULL, -- 0 (Sun) to 6 (Sat)
    startTime TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS extra_slots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT NOT NULL,
    startTime TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS blocked_slots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT NOT NULL,
    startTime TEXT NOT NULL
  );
`);

// Seed default available slots if empty
const slotCount = db.prepare("SELECT COUNT(*) as count FROM available_slots").get() as { count: number };
if (slotCount.count === 0) {
  const insertSlot = db.prepare("INSERT INTO available_slots (dayOfWeek, startTime) VALUES (?, ?)");
  // Mon (1), Tue (2), Thu (4): 16:00, 17:00
  [1, 2, 4].forEach(day => {
    insertSlot.run(day, "16:00");
    insertSlot.run(day, "17:00");
  });
  // Fri (5): 17:00
  insertSlot.run(5, "17:00");
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Request logging for debugging
  app.use((req, res, next) => {
    if (!req.url.startsWith('/@vite') && !req.url.startsWith('/src')) {
      console.log(`${req.method} ${req.url}`);
    }
    next();
  });

  // API Routes
  app.get("/api/reservations", (req, res) => {
    console.log("GET /api/reservations", req.query);
    const { month } = req.query; // YYYY-MM
    const reservations = db.prepare("SELECT * FROM reservations WHERE date LIKE ?").all(`${month}%`);
    res.json(reservations);
  });

  app.post("/api/reservations", (req, res) => {
    console.log("POST /api/reservations", req.body);
    const { date, startTime, bandName, memberCount } = req.body;
    
    // Check for double booking
    const existing = db.prepare("SELECT * FROM reservations WHERE date = ? AND startTime = ?").get(date, startTime);
    if (existing) {
      return res.status(400).json({ error: "この時間は既に予約されています。" });
    }

    const result = db.prepare("INSERT INTO reservations (date, startTime, bandName, memberCount) VALUES (?, ?, ?, ?)")
      .run(date, startTime, bandName, memberCount);
    res.json({ id: result.lastInsertRowid });
  });

  app.delete("/api/reservations/:id", (req, res) => {
    const id = parseInt(req.params.id);
    console.log(`Attempting to delete reservation with ID: ${id}`);
    
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID" });
    }

    const result = db.prepare("DELETE FROM reservations WHERE id = ?").run(id);
    console.log(`Delete result: ${JSON.stringify(result)}`);
    
    if (result.changes === 0) {
      console.warn(`No reservation found with ID: ${id}`);
    }
    
    res.json({ success: true, changes: result.changes });
  });

  app.get("/api/available-slots", (req, res) => {
    console.log("GET /api/available-slots");
    const recurring = db.prepare("SELECT * FROM available_slots").all();
    const extra = db.prepare("SELECT * FROM extra_slots").all();
    const blocked = db.prepare("SELECT * FROM blocked_slots").all();
    res.json({ recurring, extra, blocked });
  });

  app.post("/api/available-slots", (req, res) => {
    const { dayOfWeek, startTime } = req.body;
    db.prepare("INSERT INTO available_slots (dayOfWeek, startTime) VALUES (?, ?)")
      .run(dayOfWeek, startTime);
    res.json({ success: true });
  });

  app.delete("/api/available-slots/:id", (req, res) => {
    db.prepare("DELETE FROM available_slots WHERE id = ?").run(req.params.id);
    res.json({ success: true });
  });

  app.post("/api/extra-slots", (req, res) => {
    const { date, startTime } = req.body;
    db.prepare("INSERT INTO extra_slots (date, startTime) VALUES (?, ?)")
      .run(date, startTime);
    res.json({ success: true });
  });

  app.delete("/api/extra-slots", (req, res) => {
    const { date, startTime } = req.body;
    db.prepare("DELETE FROM extra_slots WHERE date = ? AND startTime = ?").run(date, startTime);
    res.json({ success: true });
  });

  app.post("/api/blocked-slots", (req, res) => {
    const { date, startTime } = req.body;
    db.prepare("INSERT INTO blocked_slots (date, startTime) VALUES (?, ?)")
      .run(date, startTime);
    res.json({ success: true });
  });

  app.delete("/api/blocked-slots", (req, res) => {
    const { date, startTime } = req.body;
    db.prepare("DELETE FROM blocked_slots WHERE date = ? AND startTime = ?").run(date, startTime);
    res.json({ success: true });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    console.log("Starting server in DEVELOPMENT mode");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    
    // Fallback for SPA
    app.get("*", async (req, res, next) => {
      // Skip API routes
      if (req.originalUrl.startsWith('/api')) return next();
      
      // Only serve index.html for requests that accept HTML
      // This prevents MIME type errors for missing JS/CSS files
      if (req.headers.accept && !req.headers.accept.includes('text/html')) {
        return next();
      }

      try {
        const url = req.originalUrl;
        const templateFile = path.resolve(process.cwd(), "index.html");
        
        if (!fs.existsSync(templateFile)) {
          console.error("index.html not found at:", templateFile);
          return res.status(404).send("index.html not found");
        }

        let template = fs.readFileSync(templateFile, "utf-8");
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e) {
        console.error("Vite transform error:", e);
        next(e);
      }
    });
  } else {
    console.log("Starting server in PRODUCTION mode");
    app.use(express.static("dist"));
    app.get("*", (req, res) => {
      res.sendFile(path.resolve("dist/index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
