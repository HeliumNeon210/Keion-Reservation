/**
 * GAS側で実行されるコード
 * スプレッドシートのIDを指定するか、スクリプトが紐付いているスプレッドシートを使用します。
 */

const SPREADSHEET_ID = ""; // 空の場合はスクリプトに紐付いたシートを使用

function getSs() {
  return SPREADSHEET_ID ? SpreadsheetApp.openById(SPREADSHEET_ID) : SpreadsheetApp.getActiveSpreadsheet();
}

/**
 * 初期設定：シートがない場合に作成する
 */
function setup() {
  const ss = getSs();
  if (!ss.getSheetByName("reservations")) {
    const sheet = ss.insertSheet("reservations");
    sheet.appendRow(["id", "date", "startTime", "bandName", "memberCount"]);
  }
  if (!ss.getSheetByName("available_slots")) {
    const sheet = ss.insertSheet("available_slots");
    sheet.appendRow(["id", "dayOfWeek", "startTime"]);
    // デフォルト枠の追加
    const defaultSlots = [
      [1, "16:00"], [1, "17:00"],
      [2, "16:00"], [2, "17:00"],
      [4, "16:00"], [4, "17:00"],
      [5, "17:00"]
    ];
    defaultSlots.forEach(slot => {
      sheet.appendRow([Utilities.getUuid(), slot[0], slot[1]]);
    });
  }
  if (!ss.getSheetByName("extra_slots")) {
    const sheet = ss.insertSheet("extra_slots");
    sheet.appendRow(["id", "date", "startTime"]);
  }
  if (!ss.getSheetByName("blocked_slots")) {
    const sheet = ss.insertSheet("blocked_slots");
    sheet.appendRow(["id", "date", "startTime"]);
  }
}

/**
 * Webアプリとして公開するためのエントリポイント
 */
function doGet(e) {
  // APIリクエスト（クエリパラメータがある場合）
  if (e && e.parameter && e.parameter.action) {
    const params = { ...e.parameter, _isExternal: true };
    return handleApiRequest(e.parameter.action, params);
  }

  // 通常の画面表示
  return HtmlService.createHtmlOutputFromFile("index")
    .setTitle("軽音班講堂予約システム")
    .addMetaTag("viewport", "width=device-width, initial-scale=1")
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/**
 * POSTリクエストの処理（API用）
 */
function doPost(e) {
  const params = JSON.parse(e.postData.contents);
  params._isExternal = true;
  const action = params.action;
  return handleApiRequest(action, params);
}

/**
 * APIリクエストの振り分け
 */
function handleApiRequest(action, params) {
  let result;
  try {
    switch (action) {
      case "getReservations":
        result = getReservations(params.month);
        break;
      case "addReservation":
        result = { id: addReservation(params.reservation) };
        break;
      case "deleteReservation":
        result = { success: deleteReservation(params.id) };
        break;
      case "getAvailableSlots":
        result = getAvailableSlots();
        break;
      case "addAvailableSlot":
        result = { id: addAvailableSlot(params.slot) };
        break;
      case "deleteAvailableSlot":
        result = { success: deleteAvailableSlot(params.id) };
        break;
      case "addExtraSlot":
        result = { success: addExtraSlot(params.date, params.startTime) };
        break;
      case "deleteExtraSlot":
        result = { success: deleteExtraSlot(params.date, params.startTime) };
        break;
      case "addBlockedSlot":
        result = { success: addBlockedSlot(params.date, params.startTime) };
        break;
      case "deleteBlockedSlot":
        result = { success: deleteBlockedSlot(params.date, params.startTime) };
        break;
      case "setup":
        setup();
        result = { success: true };
        break;
      default:
        throw new Error("Unknown action: " + action);
    }
    
    // 内部呼び出し（google.script.run）の場合はそのまま返す
    if (typeof ContentService === 'undefined' || !params._isExternal) {
      return result;
    }

    return ContentService.createTextOutput(JSON.stringify(result))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (error) {
    const errorRes = { error: error.toString() };
    if (typeof ContentService === 'undefined' || !params._isExternal) {
      throw error;
    }
    return ContentService.createTextOutput(JSON.stringify(errorRes))
      .setMimeType(ContentService.MimeType.JSON);
  }
}


/**
 * 予約一覧の取得
 */
function getReservations(month) {
  const sheet = getSs().getSheetByName("reservations");
  const data = sheet.getDataRange().getValues();
  const headers = data.shift();
  
  return data
    .filter(row => row[1].toString().startsWith(month))
    .map(row => {
      const obj = {};
      headers.forEach((header, i) => obj[header] = row[i]);
      return obj;
    });
}

/**
 * 予約の追加
 */
function addReservation(reservation) {
  const sheet = getSs().getSheetByName("reservations");
  const data = sheet.getDataRange().getValues();
  
  // 重複チェック
  const isDuplicate = data.some(row => row[1] === reservation.date && row[2] === reservation.startTime);
  if (isDuplicate) throw new Error("この時間は既に予約されています。");
  
  const id = Utilities.getUuid();
  sheet.appendRow([id, reservation.date, reservation.startTime, reservation.bandName, reservation.memberCount]);
  return id;
}

/**
 * 予約の削除
 */
function deleteReservation(id) {
  const sheet = getSs().getSheetByName("reservations");
  const data = sheet.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (data[i][0] == id) {
      sheet.deleteRow(i + 1);
      return true;
    }
  }
  return false;
}

/**
 * 予約可能枠の取得
 */
function getAvailableSlots() {
  const ss = getSs();
  const getSheetData = (name) => {
    const sheet = ss.getSheetByName(name);
    const data = sheet.getDataRange().getValues();
    const headers = data.shift();
    return data.map(row => {
      const obj = {};
      headers.forEach((header, i) => obj[header] = row[i]);
      return obj;
    });
  };

  return {
    recurring: getSheetData("available_slots"),
    extra: getSheetData("extra_slots"),
    blocked: getSheetData("blocked_slots")
  };
}

/**
 * 予約可能枠の追加
 */
function addAvailableSlot(slot) {
  const sheet = getSs().getSheetByName("available_slots");
  const id = Utilities.getUuid();
  sheet.appendRow([id, slot.dayOfWeek, slot.startTime]);
  return id;
}

/**
 * 予約可能枠の削除
 */
function deleteAvailableSlot(id) {
  const sheet = getSs().getSheetByName("available_slots");
  const data = sheet.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (data[i][0] == id) {
      sheet.deleteRow(i + 1);
      return true;
    }
  }
  return false;
}

function addExtraSlot(date, startTime) {
  const sheet = getSs().getSheetByName("extra_slots");
  sheet.appendRow([Utilities.getUuid(), date, startTime]);
  return true;
}

function deleteExtraSlot(date, startTime) {
  const sheet = getSs().getSheetByName("extra_slots");
  const data = sheet.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (data[i][1] == date && data[i][2] == startTime) {
      sheet.deleteRow(i + 1);
      return true;
    }
  }
  return false;
}

function addBlockedSlot(date, startTime) {
  const sheet = getSs().getSheetByName("blocked_slots");
  sheet.appendRow([Utilities.getUuid(), date, startTime]);
  return true;
}

function deleteBlockedSlot(date, startTime) {
  const sheet = getSs().getSheetByName("blocked_slots");
  const data = sheet.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (data[i][1] == date && data[i][2] == startTime) {
      sheet.deleteRow(i + 1);
      return true;
    }
  }
  return false;
}
